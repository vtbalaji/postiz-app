import { customFetch } from '@gitroom/helpers/utils/custom.fetch.func';

export const internalFetch = async (url: string, options: RequestInit = {}) => {
  let auth: string | undefined;
  let showorg: string | undefined;

  // Try to get cookies from next/headers (works in Server Components, not in middleware)
  try {
    const { cookies } = await import('next/headers');
    const allCookies = await cookies();
    auth = allCookies?.get('auth')?.value;
    showorg = allCookies?.get('showorg')?.value;
  } catch {
    // cookies() is not available in middleware context, that's okay
    // The cookies should be passed through headers in the request if needed
  }

  return customFetch(
    { baseUrl: process.env.BACKEND_INTERNAL_URL! },
    auth,
    showorg
  )(url, options);
};
