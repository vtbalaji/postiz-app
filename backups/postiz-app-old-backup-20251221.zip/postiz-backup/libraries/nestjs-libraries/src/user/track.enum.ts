export enum TrackEnum {
  ViewContent = 0,
  CompleteRegistration = 1,
  InitiateCheckout = 2,
  StartTrial = 3,
  Purchase = 4,
}
