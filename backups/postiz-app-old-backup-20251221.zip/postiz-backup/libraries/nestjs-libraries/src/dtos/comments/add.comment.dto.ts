export class AddCommentDto {
  content: string;
  date: string;
}
