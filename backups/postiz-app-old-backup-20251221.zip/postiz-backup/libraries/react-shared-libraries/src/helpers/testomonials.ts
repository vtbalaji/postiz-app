export const testimonials1 = [
  {
    picture: 'https://api.dicebear.com/7.x/avataaars/svg?seed=John',
    name: 'John Doe',
    description: 'Marketing Manager at TechCorp',
    content: 'Postiz has transformed how we manage our social media. Its incredibly easy to use and saves us hours every week.',
  },
  {
    picture: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
    name: 'Sarah Smith',
    description: 'Social Media Manager at Creative Studios',
    content: 'The scheduling features are amazing. We can plan our entire month in advance without any hassle.',
  },
  {
    picture: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mike',
    name: 'Mike Johnson',
    description: 'Content Creator at Digital Media',
    content: 'Best tool out there for managing multiple social media accounts. Highly recommended!',
  },
];

export const testimonials2 = [
  {
    picture: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Emma',
    name: 'Emma Wilson',
    description: 'Business Owner at Local Boutique',
    content: 'The analytics features help me understand what content resonates with my audience. Game changer!',
  },
  {
    picture: 'https://api.dicebear.com/7.x/avataaars/svg?seed=David',
    name: 'David Brown',
    description: 'Agency Director at Growth Agency',
    content: 'We manage 50+ accounts for clients. Postiz makes it seamless. Worth every penny.',
  },
  {
    picture: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Lisa',
    name: 'Lisa Anderson',
    description: 'Influencer, Independent',
    content: 'The best scheduling platform for creators. Simple, powerful, and reliable.',
  },
];
