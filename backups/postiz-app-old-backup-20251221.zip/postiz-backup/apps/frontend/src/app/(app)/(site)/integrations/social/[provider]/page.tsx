import { ContinueIntegration } from '@gitroom/frontend/components/launches/continue.integration';
export const dynamic = 'force-dynamic';
export default async function Page({
  params,
  searchParams,
}: {
  params: Promise<{
    provider: string;
  }>;
  searchParams: Promise<any>;
}) {
  const { provider } = await params;
  const searchParamsData = await searchParams;
  return <ContinueIntegration searchParams={searchParamsData} provider={provider} />;
}
