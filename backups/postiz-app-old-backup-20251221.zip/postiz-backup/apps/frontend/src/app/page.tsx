export default function RootPage(): null {
  // This page is handled by middleware.ts which redirects to /launches or /analytics
  return null;
}
