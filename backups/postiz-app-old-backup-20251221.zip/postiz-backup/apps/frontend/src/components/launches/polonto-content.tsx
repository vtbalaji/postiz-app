'use client';

import {
  useContext,
  useEffect,
  useMemo,
} from 'react';
import { createStore } from 'polotno/model/store';
import Workspace from 'polotno/canvas/workspace';
import { PolotnoContainer, SidePanelWrap, WorkspaceWrap } from 'polotno';
import { SidePanel, DEFAULT_SECTIONS } from 'polotno/side-panel';
import Toolbar from 'polotno/toolbar/toolbar';
import ZoomButtons from 'polotno/toolbar/zoom-buttons';
import { PictureGeneratorSection } from '@gitroom/frontend/components/launches/polonto/polonto.picture.generation';
import { useUser } from '@gitroom/frontend/components/layout/user.context';
import { loadVars } from '@gitroom/react/helpers/variable.context';
import { useLaunchStore } from '@gitroom/frontend/components/new-launch/store';

export const PolotnoContent = (props: {
  setMedia: (params: { id: string; path: string }[]) => void;
  type?: 'image' | 'video';
  closeModal: () => void;
  width?: number;
  height?: number;
  ActionControls: any;
  CloseContext: any;
}) => {
  const { setMedia, width, height, ActionControls, CloseContext } = props;

  const store = useMemo(() => {
    return createStore({
      get key() {
        return loadVars().plontoKey;
      },
      showCredit: false,
    });
  }, []);

  const user = useUser();
  const features = useMemo(() => {
    return [
      ...DEFAULT_SECTIONS,
      ...(user?.tier?.image_generator ? [PictureGeneratorSection] : []),
    ] as any[];
  }, [user?.tier?.image_generator]);

  useEffect(() => {
    store.addPage({
      width: width || 540,
      height: height || 675,
    });
    return () => {
      store.clear();
    };
  }, [store, width, height]);

  return (
    <PolotnoContainer
      style={{
        width: '100%',
        height: '700px',
      }}
    >
      <SidePanelWrap>
        <SidePanel store={store} sections={features} />
      </SidePanelWrap>
      <WorkspaceWrap>
        <Toolbar
          store={store}
          components={{
            ActionControls,
          }}
        />
        <Workspace store={store} />
        <ZoomButtons store={store} />
      </WorkspaceWrap>
    </PolotnoContainer>
  );
};
