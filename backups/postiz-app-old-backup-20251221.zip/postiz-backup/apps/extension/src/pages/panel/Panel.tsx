import React from 'react';
import '@pages/panel/Panel.css';

export default function Panel() {
  return (
    <div className="container">
      <h1>Side Panel</h1>
    </div>
  );
}
