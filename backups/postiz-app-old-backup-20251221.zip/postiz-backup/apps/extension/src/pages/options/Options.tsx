import React from 'react';
import '@gitroom/extension/pages/options/Options.css';

export default function Options() {
  return <div className="container">Options</div>;
}
